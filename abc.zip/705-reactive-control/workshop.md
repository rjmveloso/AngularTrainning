# Workshop for this step

* In an earlier workshop, you likely set up a plain HTML control in
  one of your components, for example to turn an age range on or off.
* Change that plain HTML control to an Angular reactive control.
* Add something similar to the button used in this example, with a
  (click) handler, to print out the results of the Angular reactive
  control.
