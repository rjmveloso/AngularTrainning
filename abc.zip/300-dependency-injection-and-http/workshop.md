# Workshop for this step

* Delete the JavaScript array of video data from the video dashboard component.

* Use the HttpClient service to load the video data from this URL:
  * 'https://api.angularbootcamp.com/videos'

