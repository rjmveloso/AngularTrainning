# Workshop for this step

* Make a new NgModule
* Make a new component
* Add the new component to the declarations of the new NgModule
* Add the new NgModule to the imports in AppModule
* Reference the new component in the template of AppComponent
