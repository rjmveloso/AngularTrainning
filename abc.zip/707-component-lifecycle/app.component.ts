import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<manager-cmp></manager-cmp>'
})
export class AppComponent {}
