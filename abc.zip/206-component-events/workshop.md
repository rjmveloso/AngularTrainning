# Workshop for this step

* Edit your video list component to emit an event when a video is selected.
* Update the video player component in the middle to display that video's
  title. (Displaying the video itself will come later.)
