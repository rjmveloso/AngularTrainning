# Workshop for this step

* Make a new NgModule
* Make a new component
* Add the new component to the declarations of the new NgModule
* Add a lazy-loaded route to the new component
* Add a link to navigate to the new route
